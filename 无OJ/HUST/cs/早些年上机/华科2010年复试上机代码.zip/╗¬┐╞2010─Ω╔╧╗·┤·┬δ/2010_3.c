/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

#define MAXLEN 10024
typedef struct Res{
    char c;//��λ��� 
    char s;//��λ��λ 
}Res;

char a[MAXLEN], b[MAXLEN];
char  c[MAXLEN];

int ChtoI(char ch)
{
    return ch - '0';
}
char ItoCh(int i)
{
    return i + '0';
}
Res Add(char pa, char pb, char ps)
{
    int i = ChtoI(pa);
    int j = ChtoI(pb);
    int k = ChtoI(ps);
    Res r ;
    r.c = i + j + k;
    r.s = ItoCh(r.c/10);
    r.c = ItoCh(r.c%10);
    return r;
}
int Length(char *s)
{
    char *p = s;
    int  n = 0;
    
    while( *p ){
       ++n;
       ++p;
    }
    
    return n;
}
int main()
{
    int i, j, k;
    char sh;
    Res r;
    while( scanf("%s%s", a, b) != EOF ){
        i = Length(a) - 1;
        j = Length(b) - 1;
        k = 0;
        sh = '0';
       while(i >= 0 && j >= 0){
          r = Add(a[i], b[j], sh);
          c[k++] = r.c; //c[k]��¼��λ��� 
          sh = r.s;//��λ��Ϊ��һ�μӷ��� 
          --i, --j;
       }
       
       while(i >= 0){
          r = Add(a[i], '0', sh);
          c[k++] = r.c;
          sh = r.s;
          --i;
       }
       
       while(j >= 0){
          r = Add('0', b[j], sh);
          c[k++] = r.c;
          sh = r.s;
          --j;
       }
       
       if(sh == '1')
         c[k] = '1' ;
       else --k;
       while(k >= 0)
         putchar(c[k--]); 
       putchar('\n');  
   
   }
   ////system("pause");
   return 0;
}
