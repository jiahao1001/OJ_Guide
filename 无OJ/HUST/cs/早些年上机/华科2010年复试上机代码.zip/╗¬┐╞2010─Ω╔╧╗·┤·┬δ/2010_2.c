/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>
/////////////////////////////////////////////
void Task0()
{
    printf("Task0 Called!\n");
}
void Task1()
{
    printf("Task1 Called!\n");
}
void Task2()
{
    printf("Task2 Called!\n");
}
void Task3()
{
    printf("Task3 Called!\n");
}
void Task4()
{
    printf("Task4 Called!\n");
}
void Task5()
{
    printf("Task5 Called!\n");
}
void Task6()
{
    printf("Task6 Called!\n");
}
void Task7()
{
    printf("Task7 Called!\n");
}
void Task8()
{
    printf("Task8 Called!\n");
}
////////////////////////////////////////////
void Execute(void (*ef[])(), int n)
{
    int i = 0;
    while(i < n){
       (ef[i])();
       ++i;
    }
}

void Schedule(char *in)
{
    char *p = in;
    void (*f[])() = {Task0, Task1, Task2, Task3, Task4, Task5, Task6, Task7, Task8};
    void (*ef[10024])();
    int i = 0;
    while( *p ){
       ef[i++] = f[*p - '0']; 
       ++p;
    }
    Execute(ef, i);
}
int main()
{ 
   char s[10024]; 
   while(gets(s) != NULL){
      Schedule(s);
   } 
   system("pause");
   return 0;
}
