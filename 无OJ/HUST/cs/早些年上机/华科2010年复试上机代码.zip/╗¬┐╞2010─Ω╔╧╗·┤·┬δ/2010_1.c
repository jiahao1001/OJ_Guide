/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

void Check(char* pc)
{
    char ch = *pc;
    int stack[8] = {0};
    int i, j;
    int count = 0;
    
    i = 0;
    while(ch){
       if( (stack[i++]=ch%2) ){
           ++count;
       }
       ch /= 2;
    }
    
    if( !(count&1) ){//����ż����1
        stack[7] ^= 1;
        *pc = (*pc)^(1<<7);
    }
    
    for(j = 7; j >= 0; --j)
      printf("%d", stack[j]);
    printf("\n");
}
int main()
{
   char str[10024];
   char *p;
   while( gets(str) != NULL ){
      p = str;
      while( *p ){
         Check(p);
         ++p;
      }
   } 
   system("pause");
   return 0;
}
