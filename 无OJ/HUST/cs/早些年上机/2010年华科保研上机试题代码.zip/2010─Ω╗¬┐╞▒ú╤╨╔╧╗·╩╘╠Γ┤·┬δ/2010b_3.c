/*
  Description:ע�⣺Ҫ�Ѵӵ�λÿ��λ���֣�Ȼ����ӽ�λ�����ܵó���ȷ��� 
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

typedef struct List{
   int data;//�����λ���� 
   struct List* next;
}List, *ListPtr;

typedef struct Res{
   int c;//���ؽ�� 
   int s;//��λ��� 
}Res;
 
ListPtr CreateNode(int x)
{
    ListPtr p = (List *)malloc(sizeof(List));
    p->data = x;
    p->next = NULL;
}
int Split(char *s, int high)
{
    int low = high>3?high-3:0;
    int x = 0;
    
    if(high < 0)
      return -1;
      
    while(low <= high){
       x = x*10 + s[low] - '0';
       ++low;
    }
    
    return x;
}
ListPtr CreateList(char *s)
{
    int x ;
    ListPtr q;
    int n = strlen(s) - 1;
     
    ListPtr head = (List *)malloc(sizeof(List));
    head->next = head;
    
    /*������������λ��ǰ�� ��λ�ں�*/
    while( (x =Split(s, n)) != -1 ){
       q = CreateNode(x);
       /*������p���֮��*/ 
       q->next = head->next;
       head->next = q;
       n -= 4;
       
    }
    
    return head;
}

Res add(ListPtr p, ListPtr q, int sw)
{
    Res r ;
    int x = p!=NULL?(p->data):0;
    int y = q!=NULL?(q->data):0;
     
    r.c = (x + y + sw)%10000;
    r.s = (x + y + sw)/10000;
    //printf("���أ�%d,��λ��%d\n", r.c, r.s);
    return r;
}
void Reverse(ListPtr h)
{
    ListPtr q;
    ListPtr p = h->next;
    h->next = h;
    
    while(p != h){
       q = p->next;
       p->next = h->next;
       h->next = p;
       p = q;
    } 
}


ListPtr BigAdd(ListPtr h1, ListPtr h2)
{//����Ӻ�Ľ����λ�������������
      ListPtr p, q, t;
      Res r ;
      ListPtr result = (List *)malloc(sizeof(List));
      result->next = result;
      
      Reverse(h1);
      Reverse(h2);
      
      p = h1->next;
      q = h2->next;
      
      int sw = 0;
      
      while(p != h1 && q != h2){
          r = add(p, q, sw);
          t = CreateNode(r.c);
          t->next = result->next;
          result->next = t;
          
          sw = r.s;
          
          p = p->next;
          q = q->next;
      }
      
      while(p != h1){
          r = add(p, NULL, sw);
          t = CreateNode(r.c);
          t->next = result->next;
          result->next = t;
          
          sw = r.s;
          p = p->next;
         
      }
      
      while(q != h2){
          r = add(NULL, q, sw);
          t = CreateNode(r.c);
          t->next = result->next;
          result->next = t;
          
          sw = r.s;
          q = q->next;
          
      }
      
      if(sw != 0){
         t = CreateNode(sw);
         t->next = result->next;
         result->next = t;
      }
      
      Reverse(h1);
      Reverse(h2);
       
      return result;
    
}

void Print(ListPtr h)
{
    ListPtr p = h->next;
    while( p != h){
       printf("%d", p->data);
       p = p->next;
    }
}

int main()
{
   char str1[10024], str2[10024];
   ListPtr h1, h2, result;
   while( scanf("%s%s", str1, str2) != EOF ){ 
       
     h1 = CreateList(str1); 
     h2 = CreateList(str2);
     
     Print(h1);
     printf(" + ");
     Print(h2);
     printf(" = ");
   
     result = BigAdd(h1, h2);
     Print(result);
     printf("\n");
   }
   system("pause");
   return 0;
}
