/*
  Description:���������������� 
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

typedef struct BTree{
    int data;
    struct BTree* lchild;
    struct BTree* rchild;
}BTree, *BTreePtr;
void Insert(BTreePtr *t,  int x)
{
    BTreePtr p = *t;
    if( p == NULL ){
       *t = (BTree *)malloc(sizeof(BTree));
       (*t)->data = x;
       (*t)->lchild = NULL;
       (*t)->rchild = NULL;
    }
    else if(x < p->data){
       Insert(&(p->lchild), x);
    }
    else Insert(&(p->rchild), x);
}

void PreOrder(BTreePtr t)
{
    if(t != NULL ){
       printf("%4d", t->data);
       PreOrder(t->lchild);
       PreOrder(t->rchild);
    } 
}

int main()
{
   int data;
   BTreePtr root = NULL;
   
   printf("������һ����(Ctrl+Z����):"); 
   while( scanf("%d", &data) != EOF ){
       Insert(&root, data);
   }
   
   printf("���������:");
   PreOrder(root);
   printf("\n"); 
   system("pause");
   return 0;
}
