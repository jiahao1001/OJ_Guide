/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

typedef struct Store{
   char* data;
   struct Store *next; 
}Store, *StorePtr;/* �����������ⳤ�ȵ����������ݽṹ */

typedef struct BigInt{
    char data;
    struct BigInt *next;
}BigInt;/*��������ʽ���������Ȼ��ת��Ϊ������洢���ַ��� */

typedef struct RES{
   char c;
   char s;
}RES;/* �ӷ����� */

BigInt* MakeNode_BigInt(char ch)
{
    BigInt* p = (BigInt *)malloc(sizeof(BigInt));
    p->data = ch;
    p->next = NULL;
    return p;
}

/*������������ת��Ϊ�ַ���*/
char* ItoStr(BigInt *h, int len)
{
    char *s = (char *)malloc(len + 1);
    BigInt* p = h->next;
    BigInt* q; 
    int i = 0;
    
    while( p != NULL ){
       s[i++] = p->data;
       q = p;
       p = p->next;
       free(q);
    }
    free(h);
    
    s[i] = '\0';
    
    return s;
}
/*��������������*/
BigInt* CreateBigInt(int *len)
{
    int count = 0;
    BigInt *q, *p;
    char ch;
    
    BigInt *head = MakeNode_BigInt('\0');
    head->next = NULL;
    
    ch = getchar();
    if(ch == EOF){
       return NULL;
    }
    ++count;
    p = head;
    while( ch != '\n' ){
       q = MakeNode_BigInt(ch);
       p->next = q;
       p = q;
       
       ch = getchar();
       ++count;
    }
    
    *len = count - 1;
    return head;
}


Store* MakeNode_Store(char* str)
{
    Store* p = (Store *)malloc(sizeof(Store));
    p->data = str;
    p->next = NULL;
}

/*����������ݿ�����������(�Ǵ���������ת������ַ���)*/
void InsertBigInt(Store *h, char *str)
{
    StorePtr p = (Store *)malloc(sizeof(Store));
    p->data = str;
    p->next = h->next;
    h->next = p;
}



char ItoCh(int x)
{
   return x + '0';
}
int ChtoI(char ch)
{
    return ch - '0';
}
RES add(char a, char b, char c)
{
    int x = ChtoI(a);
    int y = ChtoI(b);
    int z = ChtoI(c);
    int sum = x + y + z;
    RES r;
    r.c = ItoCh(sum%10);
    r.s = ItoCh(sum/10);
    
    return r;
}

/*ʵ�ִ������ӷ�*/ 
char* BigIntAdd(char *pa, char *pb)
{
    char *t ;
    int i = strlen(pa) - 1;
    int j = strlen(pb) - 1;
    int len = 0;
    
    BigInt* p;
    RES r;
    char sw;
    
    BigInt* result = MakeNode_BigInt('\0');
    result->next = NULL;
    
    sw = '0';
    while(i >= 0 && j >= 0){
       r = add(pa[i], pb[j], sw);
       
       p = MakeNode_BigInt(r.c);
       p->next = result->next;
       result->next = p;
       ++len;
       
       sw = r.s;
        
       --i, --j;
    }
    
    while(i >= 0){
       r = add(pa[i], '0', sw);
       p = MakeNode_BigInt(r.c);
       p->next = result->next;
       result->next = p;
       ++len;
       
       sw = r.s;
       
       --i;
    }
    
    while(j >= 0){
       r = add('0', pb[j], sw);
       p = MakeNode_BigInt(r.c);
       p->next = result->next;
       result->next = p;
       ++len;
       
       sw = r.s;
       
       --j;
    }
    
    if(sw == '1'){
       p = MakeNode_BigInt('1');
       p->next = result->next;
       result->next = p;
       ++len;
    }
    
    t = ItoStr(result, len);
    return t;
}

/*�Դ��������ݿ��ۼ����*/
char* SumStore(Store *h)
{
    StorePtr p = h->next;
    char *result ;
    BigInt* temp ;
    
    if(p != NULL){
      result = p->data;
      p = p->next;
    }
    
    while( p != NULL ){ 
       result = BigIntAdd(result, p->data);
       p = p->next;
    }
    
    return result;
}

/*��ӡ���������ݿ�*/
void PrintStore(StorePtr h)
{
    StorePtr p = h->next;
    puts("���������ݿ�Ϊ:");
    while( p != NULL ){
       puts(p->data);
       p = p->next;
    }
}

int Compare(char *s1, char *s2)
{
    int n1 = strlen(s1);
    int n2 = strlen(s2);
    
    if(n1 != n2){
      return n1 - n2;
    }
    
    return strcmp(s1, s2);
}

/*�Դ��������ݿ���в�������*/
void InsertSort(StorePtr h, StorePtr s)
{
    StorePtr p = h;
    while( p->next ){
       if( Compare(s->data, p->next->data) < 0 )
         break;
        p = p->next;
    }
    //printf("����һ��\n");
    s->next = p->next;
    p->next = s;
}
void SortStore(StorePtr h)
{
    StorePtr q ;
    StorePtr p = h->next;
    h->next = NULL;
    
    while( p != NULL ){
        q = p->next;
        InsertSort(h, p);
        p = q;
    }
}
int main()
{
   BigInt *pa, *pb, *pc;
   int len = 0;
   char *s;
   char* sumPtr;
   StorePtr ps = MakeNode_Store("");
   ps->next = NULL;
   
   while( (pa = CreateBigInt(&len)) != NULL){
      s = ItoStr(pa, len);
      //puts(s);
      InsertBigInt(ps, s);    
   }
   
   PrintStore(ps);
   sumPtr = SumStore(ps);
   printf("�ۼӺ�:%s\n", sumPtr);
   
   printf("�Դ��������ݿ������:\n");
   SortStore(ps);
   PrintStore(ps);
   
   system("pause");
   return 0;
}
