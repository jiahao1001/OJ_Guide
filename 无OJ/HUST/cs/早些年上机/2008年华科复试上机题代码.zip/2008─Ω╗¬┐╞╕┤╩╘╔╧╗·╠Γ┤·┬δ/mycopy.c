/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

FILE* OpenFile(char *file, int flag)
{
    FILE *fp = fopen(file, flag?"w":"r");
    if(fp == NULL){
       printf("�ļ�%s���ܴ�!\n", file);
       exit(1);
    }
    return fp;
}

void CopyFile(FILE* fp1, FILE *fp)
{
    char ch;
    ch = fgetc(fp);
    while( !feof(fp) ){
       fputc(ch, fp1);
       ch = fgetc(fp);
    }
}
int main(int argc, char *argv[])
{
   FILE *fp1 = OpenFile(argv[1], 1);
   FILE *fp;
   int i;
   int n = argc;
   
   for(i = 2; i < n; ++i){
      fp = OpenFile(argv[i], 0);
      CopyFile(fp1, fp);
      //fprintf(fp1, "�ļ�%s���ƽ���!\n", argv[i]);
      fclose(fp);
   }
   fclose(fp1);
   system("pause");
   return 0;
}
