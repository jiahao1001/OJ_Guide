/*
  Description:
*/
#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
#include<ctype.h>
#include<string.h>

int CheckFirst(char ch)
{
    if(isalpha(ch) || ch == '_')
     return 1;
    return 0;
}
int main()
{
   char ch;
   int count = 0;
   ch = getchar();
   ++count;
   if( !CheckFirst(ch) ){
      printf("�������Ϸ�!\n");
      system("pause");
      return 0;
   }
   ch = getchar();
   ++count;
   while( ch != '\n' ){
      if( isalnum(ch) || ch == '_'){
         ch = getchar();
         ++count;
      }
      else {
         printf("�������Ϸ�!\n");
         system("pause");
         return 0;
      }
   }
   count -= 1;
   if(count <= 255)
     printf("�����Ϸ�!\n");
   else printf("�������Ϸ�!\n");
    
   system("pause");
   return 0;
}
